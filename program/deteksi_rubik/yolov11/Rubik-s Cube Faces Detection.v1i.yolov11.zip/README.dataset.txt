# Rubik's Cube Faces Detection > 2025-06-18 12:55am
https://universe.roboflow.com/tairjaa/rubik-s-cube-faces-detection

Provided by a Roboflow user
License: CC BY 4.0

